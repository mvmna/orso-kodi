# Kodi Program Add-on entrypoint.
# This script provides a simple menu UI.
# Keep this file small: delegate work to resources/lib modules.

import sys
from resources.lib.ui import Router

if __name__ == "__main__":
    Router(sys.argv).dispatch()