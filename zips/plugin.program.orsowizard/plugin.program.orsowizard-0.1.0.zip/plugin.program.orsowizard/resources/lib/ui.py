import urllib.parse
import xbmcgui
import xbmcplugin

from .maintenance import run_maintenance_menu, clear_packages, clear_thumbnails, clear_addon_data_cache, update_check
from .repo_installer import run_repo_installer_menu
from .umbrestuary_setup import run_umbrestuary_setup_menu
from .api_keys import run_api_keys_menu
from .kodi_config import run_kodi_config_menu
from .telemetry import log

class Router:
    """
    Basic router for plugin-style navigation.
    Kodi calls the addon with plugin:// URL params.
    """
    def __init__(self, argv):
        self.argv = argv
        self.handle = int(argv[1]) if len(argv) > 1 else -1
        self.base_url = argv[0] if argv else ""

    def dispatch(self):
        params = self._parse_params(self.argv[2] if len(self.argv) > 2 else "")
        action = params.get("action")

        if not action:
            return self._main_menu()

        if action == "setup":
            return self._setup_menu()

        if action == "maintenance":
            return run_maintenance_menu(self.handle, self.base_url)

        if action == "maintenance_run":
            task = params.get("task")
            tasks = {
                "clear_packages": clear_packages,
                "clear_thumbnails": clear_thumbnails,
                "clear_addon_data_cache": clear_addon_data_cache,
                "update_check": update_check,
            }
            if task in tasks:
                tasks[task]()
                xbmcgui.Dialog().notification("Orso Wizard", f"Completed: {task}", time=2000)
            return

        if action == "repos":
            return run_repo_installer_menu(self.handle, self.base_url)

        if action == "apikeys":
            return run_api_keys_menu(self.handle, self.base_url)

        if action == "skin":
            return run_umbrestuary_setup_menu(self.handle, self.base_url)

        if action == "kodiconfig":
            return run_kodi_config_menu(self.handle, self.base_url)

        xbmcgui.Dialog().ok("Orso Wizard", f"Unknown action: {action}")

    def _main_menu(self):
        xbmcplugin.setPluginCategory(self.handle, "Orso Wizard")

        self._add_item("Setup Wizard", {"action": "setup"})
        self._add_item("Maintenance", {"action": "maintenance"})
        self._add_item("Install Repositories", {"action": "repos"})
        self._add_item("Configure Umbrella (Debrid/Trakt)", {"action": "apikeys"})
        self._add_item("Umbrestuary Widget Setup", {"action": "skin"})
        self._add_item("Kodi Settings (cache/performance)", {"action": "kodiconfig"})

        xbmcplugin.endOfDirectory(self.handle)

    def _setup_menu(self):
        """
        A 'guided' setup that runs steps in order.
        Keep steps idempotent.
        """
        xbmcplugin.setPluginCategory(self.handle, "Setup Wizard")

        self._add_item("1) Install Repositories (The Crew + The Loop)", {"action": "repos"})
        self._add_item("2) Configure Umbrella (Real Debrid / Trakt)", {"action": "apikeys"})
        self._add_item("3) Apply Umbrestuary Widgets", {"action": "skin"})
        self._add_item("4) Configure Kodi Settings (cache on startup)", {"action": "kodiconfig"})
        self._add_item("5) Run Maintenance (optional)", {"action": "maintenance"})

        xbmcplugin.endOfDirectory(self.handle)

    def _add_item(self, title, params):
        url = self._build_url(params)
        li = xbmcgui.ListItem(label=title)
        xbmcplugin.addDirectoryItem(self.handle, url, li, isFolder=True)

    def _build_url(self, params):
        return f"{self.base_url}?{urllib.parse.urlencode(params)}"

    def _parse_params(self, paramstring):
        if paramstring.startswith("?"):
            paramstring = paramstring[1:]
        return dict(urllib.parse.parse_qsl(paramstring))