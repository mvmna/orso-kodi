import xbmcgui
import xbmcaddon

from .telemetry import log
from .kodi import set_addon_setting

UMBRELLA_ADDON_ID = "plugin.video.umbrella"


def run_api_keys_menu(handle, base_url):
    """Configure API keys for Umbrella (Real Debrid, Trakt, etc.)"""
    dialog = xbmcgui.Dialog()

    try:
        addon = xbmcaddon.Addon(UMBRELLA_ADDON_ID)
        
        choice = dialog.yesno(
            "Orso Wizard",
            "Configure Umbrella?\n\n"
            "This opens Umbrella settings where you can:\n"
            "- Authorize Real Debrid\n"
            "- Authorize Trakt\n"
            "- Set playback preferences"
        )
        
        if choice:
            addon.openSettings()
            dialog.notification("Orso Wizard", "Umbrella settings opened", time=2000)
            
            # Offer to configure auto-select after settings
            if dialog.yesno(
                "Orso Wizard",
                "Enable auto-select for torrents?\n\n"
                "This will automatically select the best source\n"
                "when playing content from Umbrella."
            ):
                configure_umbrella_autoselect()
                dialog.notification("Orso Wizard", "Auto-select enabled", time=2000)
                
    except Exception as e:
        log(f"Umbrella not installed: {e}")
        dialog.ok(
            "Orso Wizard",
            "Umbrella addon not found.\n\n"
            "Please install it first:\n"
            "1. Run 'Install Repositories'\n"
            "2. Install Umbrella from the Umbrella repo"
        )


def configure_umbrella_autoselect():
    """Set Umbrella to auto-select best torrent source."""
    settings = [
        ("autoplay.enable", "true"),
        ("autoplay.sd", "true"),
        ("autoplay.hd", "true"),
    ]

    success = True
    for setting_id, value in settings:
        if not set_addon_setting(UMBRELLA_ADDON_ID, setting_id, value):
            success = False
            log(f"Failed to set {setting_id}")

    if success:
        log("Umbrella auto-select configured successfully")
    
    return success
