import os
import shutil
import xbmc
import xbmcgui
import xbmcvfs

from .telemetry import log

def run_maintenance_menu(handle, base_url):
    import xbmcplugin
    xbmcplugin.setPluginCategory(handle, "Maintenance")

    def add(title, action):
        import urllib.parse, xbmcgui, xbmcplugin
        url = f"{base_url}?{urllib.parse.urlencode({'action': 'maintenance_run', 'task': action})}"
        li = xbmcgui.ListItem(label=title)
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)

    add("Clear Packages", "clear_packages")
    add("Clear Thumbnails", "clear_thumbnails")
    add("Clear Addon Data Cache (selectively)", "clear_addon_data_cache")
    add("Trigger Kodi Add-on Update Check", "update_check")

    xbmcplugin.endOfDirectory(handle)

    # Router-less action handling:
    # Kodi will call our plugin again for maintenance_run tasks, but to keep this scaffold minimal,
    # we also support calling tasks directly through builtins in future refinement.

def _userdata_path():
    return xbmcvfs.translatePath("special://home/userdata/")

def _profile_path():
    return xbmcvfs.translatePath("special://profile/")

def clear_packages():
    path = xbmcvfs.translatePath("special://home/addons/packages/")
    _rm_tree(path)

def clear_thumbnails():
    path = xbmcvfs.translatePath("special://profile/Thumbnails/")
    _rm_tree(path)

def clear_addon_data_cache():
    # NOTE: Be careful. Many add-ons store credentials in addon_data.
    # This should be a selective list you control.
    addon_data = xbmcvfs.translatePath("special://profile/addon_data/")
    safe_targets = [
        # Example placeholders:
        # os.path.join(addon_data, "plugin.program.orsowizard", "cache"),
    ]
    for p in safe_targets:
        _rm_tree(p)

def update_check():
    # Builtin triggers repository/addon update checks.
    xbmc.executebuiltin("UpdateAddonRepos")
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmcgui.Dialog().notification("Orso Wizard", "Triggered update check", time=3000)

def _rm_tree(path):
    try:
        if not path or not xbmcvfs.exists(path):
            return
        # xbmcvfs doesn't have full shutil parity, so use os/shutil where possible.
        if os.path.isdir(path):
            shutil.rmtree(path, ignore_errors=True)
        else:
            try:
                os.remove(path)
            except Exception:
                pass
        log(f"Removed: {path}")
    except Exception as e:
        xbmcgui.Dialog().ok("Orso Wizard", f"Failed to remove:\n{path}\n\n{e}")