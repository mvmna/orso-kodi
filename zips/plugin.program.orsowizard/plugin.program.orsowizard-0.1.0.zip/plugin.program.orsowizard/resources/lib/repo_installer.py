import os
import xbmcgui
import xbmcvfs

from .net import download_to_file
from .telemetry import log
from .kodi import install_zip

def run_repo_installer_menu(handle, base_url):
    """
    Generic repository installer:
    - Reads repo zip URLs from add-on settings
    - Downloads and installs via "Install from zip" mechanism programmatically

    NOTE: This module intentionally does NOT hardcode third-party repos.
    Users must provide URLs themselves (or you can list official/legal repos).
    """
    import xbmcaddon
    addon = xbmcaddon.Addon()
    urls = [
        addon.getSetting("repo_zip_url_1").strip(),
        addon.getSetting("repo_zip_url_2").strip(),
        addon.getSetting("repo_zip_url_3").strip(),
    ]
    urls = [u for u in urls if u]

    if not urls:
        xbmcgui.Dialog().ok(
            "Orso Wizard",
            "No repository ZIP URLs configured.\n\nSet them in this add-on's settings under 'Repositories'.",
        )
        return

    ok = xbmcgui.Dialog().yesno(
        "Orso Wizard",
        f"Install {len(urls)} repository ZIP(s) now?\n\nThis will download ZIPs and trigger install.",
    )
    if not ok:
        return

    dest_dir = xbmcvfs.translatePath("special://home/addons/packages/")
    if not xbmcvfs.exists(dest_dir):
        xbmcvfs.mkdirs(dest_dir)

    for url in urls:
        try:
            filename = os.path.basename(url.split("?")[0]) or "repo.zip"
            dest = os.path.join(dest_dir, filename)
            log(f"Downloading repo zip: {url} -> {dest}")
            download_to_file(url, dest)
            install_zip(dest)
        except Exception as e:
            xbmcgui.Dialog().ok("Orso Wizard", f"Failed installing repo:\n{url}\n\n{e}")

    xbmcgui.Dialog().notification("Orso Wizard", "Repo install complete", time=3500)