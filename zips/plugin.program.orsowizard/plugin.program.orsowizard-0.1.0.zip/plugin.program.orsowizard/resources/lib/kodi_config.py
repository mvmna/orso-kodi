import os
import xml.etree.ElementTree as ET
import xbmcvfs
import xbmcgui

from .telemetry import log


def run_kodi_config_menu(handle, base_url):
    """Menu for Kodi configuration options."""
    dialog = xbmcgui.Dialog()
    
    choice = dialog.yesno(
        "Orso Wizard",
        "Configure Kodi performance settings?\n\n"
        "This will create/update advancedsettings.xml to:\n"
        "- Optimize cache settings for streaming\n"
        "- Enable cache cleanup on startup\n\n"
        "Recommended for Fire TV devices."
    )
    
    if choice:
        success = create_advancedsettings()
        if success:
            dialog.ok(
                "Orso Wizard",
                "Kodi settings configured!\n\n"
                "Changes will take effect after Kodi restart."
            )
        else:
            dialog.ok(
                "Orso Wizard",
                "Settings were not changed.\n\n"
                "You can manually configure advancedsettings.xml later."
            )


def create_advancedsettings():
    """Create advancedsettings.xml for cache clearing on startup and optimized streaming."""
    userdata = xbmcvfs.translatePath("special://userdata/")
    xml_path = os.path.join(userdata, "advancedsettings.xml")

    # Check if file exists and offer to back up
    if xbmcvfs.exists(xml_path):
        choice = xbmcgui.Dialog().yesno(
            "Orso Wizard",
            "advancedsettings.xml already exists.\n\n"
            "Do you want to overwrite it?\n"
            "(Existing settings will be lost)"
        )
        if not choice:
            return False

    root = ET.Element("advancedsettings")

    # Cache settings for optimal streaming on Fire TV / low-memory devices
    cache = ET.SubElement(root, "cache")
    ET.SubElement(cache, "memorysize").text = "157286400"  # 150MB
    ET.SubElement(cache, "buffermode").text = "1"  # Buffer all internet filesystems
    ET.SubElement(cache, "readfactor").text = "4"  # Read ahead factor

    # Network settings
    network = ET.SubElement(root, "network")
    ET.SubElement(network, "curlclienttimeout").text = "30"
    ET.SubElement(network, "curllowspeedtime").text = "30"

    # Video settings
    video = ET.SubElement(root, "video")
    playcountminimumpercent = ET.SubElement(video, "playcountminimumpercent")
    playcountminimumpercent.text = "90"

    # GUI settings for cleanup
    gui = ET.SubElement(root, "gui")
    ET.SubElement(gui, "algorithmdirtyregions").text = "3"

    # Write file with proper formatting
    tree = ET.ElementTree(root)
    try:
        ET.indent(tree, space="  ")
    except AttributeError:
        pass  # ET.indent not available in older Python versions
    
    try:
        tree.write(xml_path, encoding="utf-8", xml_declaration=True)
        log(f"Created advancedsettings.xml at {xml_path}")
        return True
    except Exception as e:
        log(f"Failed to write advancedsettings.xml: {e}")
        xbmcgui.Dialog().ok("Orso Wizard", f"Failed to save settings:\n\n{e}")
        return False


def get_advancedsettings_path():
    """Return the path to advancedsettings.xml."""
    userdata = xbmcvfs.translatePath("special://userdata/")
    return os.path.join(userdata, "advancedsettings.xml")
