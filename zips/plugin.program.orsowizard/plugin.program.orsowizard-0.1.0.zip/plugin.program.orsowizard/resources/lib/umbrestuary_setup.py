import xbmc
import xbmcgui

from .telemetry import log
from .kodi import jsonrpc

# Widget presets for Orso build
# Format: (widget_num, label, plugin_path, content_type)
WIDGET_PRESETS = [
    (1, "Umbrella Movies", "plugin://plugin.video.umbrella/?action=movieNavigator", "files"),
    (2, "Umbrella TV Shows", "plugin://plugin.video.umbrella/?action=tvNavigator", "files"),
    (3, "The Crew Sports", "plugin://plugin.video.thecrew/?action=sports", "files"),
    (4, "The Crew IPTV", "plugin://plugin.video.thecrew/?action=iptv", "files"),
    (5, "The Loop Live", "plugin://plugin.video.theloop/?action=sport_menu", "files"),
    (6, "PVR TV Channels", "pvr://channels/tv/All channels/", "files"),
]


def run_umbrestuary_setup_menu(handle, base_url):
    """Configure Umbrestuary home screen widgets."""
    dialog = xbmcgui.Dialog()

    # Verify Umbrestuary is active
    resp = jsonrpc("Settings.GetSettingValue", {"setting": "lookandfeel.skin"})
    skin = resp.get("result", {}).get("value", "")
    log(f"Active skin: {skin}")

    if "umbrestuary" not in skin.lower():
        dialog.ok(
            "Orso Wizard",
            f"Umbrestuary skin not active.\n\n"
            f"Current skin: {skin}\n\n"
            "Please activate Umbrestuary first in\n"
            "Settings > Interface > Skin"
        )
        return

    if not dialog.yesno(
        "Orso Wizard",
        "Apply Orso widget preset?\n\n"
        "This will configure home screen widgets for:\n"
        "- Umbrella (Movies/TV Shows)\n"
        "- The Crew (Sports/IPTV)\n"
        "- The Loop (Live Sports)\n"
        "- PVR Channels"
    ):
        return

    # Apply widget settings
    applied = 0
    for num, label, path, content in WIDGET_PRESETS:
        try:
            xbmc.executebuiltin(f'Skin.SetString(Widget{num}Path, "{path}")')
            xbmc.executebuiltin(f'Skin.SetString(Widget{num}Content, "{content}")')
            xbmc.executebuiltin(f'Skin.SetString(Widget{num}Label, "{label}")')
            log(f"Set widget {num}: {label} -> {path}")
            applied += 1
        except Exception as e:
            log(f"Failed to set widget {num}: {e}")

    if applied > 0:
        dialog.notification("Orso Wizard", f"Configured {applied} widgets!", time=3000)
        
        # Offer to reload skin for changes to take effect
        if dialog.yesno(
            "Orso Wizard",
            "Widgets configured!\n\n"
            "Reload skin now to see changes?\n"
            "(Recommended)"
        ):
            xbmc.executebuiltin("ReloadSkin()")
    else:
        dialog.ok(
            "Orso Wizard",
            "No widgets were configured.\n\n"
            "Widget paths may differ in your Umbrestuary version.\n"
            "You may need to configure widgets manually."
        )


def get_current_skin():
    """Return the currently active skin ID."""
    resp = jsonrpc("Settings.GetSettingValue", {"setting": "lookandfeel.skin"})
    return resp.get("result", {}).get("value", "")