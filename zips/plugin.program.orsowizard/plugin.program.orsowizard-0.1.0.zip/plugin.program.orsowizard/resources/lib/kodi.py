import json
import xbmc
import xbmcaddon

from .telemetry import log

def jsonrpc(method, params=None):
    payload = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        payload["params"] = params
    raw = xbmc.executeJSONRPC(json.dumps(payload))
    try:
        return json.loads(raw)
    except Exception:
        return {"raw": raw}

def enable_addon(addon_id: str):
    # Kodi 19+ supports Addons.SetAddonEnabled via JSON-RPC
    resp = jsonrpc("Addons.SetAddonEnabled", {"addonid": addon_id, "enabled": True})
    log(f"Enable addon {addon_id}: {resp}")
    return resp

def set_addon_setting(addon_id: str, setting_id: str, value: str):
    """
    Programmatically set another add-on's setting.
    This works if the add-on is installed.
    """
    try:
        a = xbmcaddon.Addon(addon_id)
        a.setSetting(setting_id, value)
        log(f"Set {addon_id}.{setting_id} = {value}")
        return True
    except Exception as e:
        log(f"Failed setSetting {addon_id}.{setting_id}: {e}")
        return False

def install_zip(zip_path: str):
    """
    Trigger install from zip. Kodi built-in expects a path.
    """
    # InstallFromZip is a FileBrowser flow; InstallAddon is for repo installs.
    # Many builds accept: InstallFromZip(<path>).
    xbmc.executebuiltin(f'InstallFromZip("{zip_path}")')
    log(f"InstallFromZip: {zip_path}")