import xbmc
import xbmcgui
import xbmcaddon

from .maintenance import clear_packages, clear_thumbnails, update_check, quick_clean
from .repo_installer import run_repo_installer
from .addon_installer import run_addon_installer
from .umbrestuary_setup import run_umbrestuary_setup
from .api_keys import run_api_keys
from .kodi_config import run_kodi_config
from .telemetry import log


def run_wizard():
    """Main entry point for the wizard script."""
    _show_welcome_if_first_run()
    _main_menu()


def _main_menu():
    """Show main menu as a dialog."""
    dialog = xbmcgui.Dialog()
    
    menu_items = [
        ("1. Install Repositories", "repos"),
        ("2. Install Streaming Addons", "addons"),
        ("3. Configure Real Debrid / Trakt", "apikeys"),
        ("4. Set Up Home Screen", "skin"),
        ("5. Optimize Kodi", "kodiconfig"),
        ("Maintenance", "maintenance"),
        ("Help", "about"),
    ]
    
    while True:
        choice = dialog.select(
            "Orso Wizard",
            [item[0] for item in menu_items]
        )
        
        if choice < 0:  # User pressed back/cancel
            break
        
        action = menu_items[choice][1]
        
        if action == "repos":
            run_repo_installer()
        elif action == "addons":
            if run_addon_installer():
                # If addon installer navigated away, exit the menu
                break
        elif action == "apikeys":
            run_api_keys()
        elif action == "skin":
            if run_umbrestuary_setup():
                # If user needs to install/activate skin, exit the menu
                break
        elif action == "kodiconfig":
            run_kodi_config()
        elif action == "maintenance":
            _maintenance_submenu()
        elif action == "about":
            _show_about()


def _maintenance_submenu():
    """Show maintenance as a submenu dialog."""
    dialog = xbmcgui.Dialog()
    
    items = [
        ("Quick Clean", quick_clean),
        ("Clear Packages", clear_packages),
        ("Clear Thumbnails", clear_thumbnails),
        ("Check for Updates", update_check),
    ]
    
    choice = dialog.select("Maintenance", [i[0] for i in items])
    if choice >= 0:
        items[choice][1]()


def _show_welcome_if_first_run():
    """Show a brief welcome on first run."""
    addon = xbmcaddon.Addon()
    if addon.getSetting("first_run_shown") == "true":
        return
        
    xbmcgui.Dialog().ok(
        "Welcome to Orso Wizard",
        "Follow steps 1-5 to set up Kodi for streaming.\n\n"
        "[COLOR yellow]IMPORTANT: Real Debrid account required[/COLOR]\n"
        "for Movies & TV Shows (Umbrella addon).\n\n"
        "Sports streaming (The Crew) is free."
    )
    addon.setSetting("first_run_shown", "true")


def _show_about():
    """Help topics - detailed explanations on demand."""
    dialog = xbmcgui.Dialog()
    
    options = [
        "What is Real Debrid?",
        "What is Trakt?",
        "What is Umbrella?",
        "What is The Crew?",
        "Do I need a VPN?",
        "Troubleshooting",
    ]
    
    choice = dialog.select("Help", options)
    
    if choice == 0:
        dialog.ok(
            "Real Debrid",
            "[COLOR yellow]REQUIRED for Umbrella (Movies/TV)[/COLOR]\n\n"
            "Premium service (~$3-5/month) that provides\n"
            "fast, high-quality cached torrent streams.\n\n"
            "Sign up at real-debrid.com\n"
            "Then connect it in step 3."
        )
    elif choice == 1:
        dialog.ok(
            "Trakt",
            "Free service that tracks what you watch.\n"
            "Syncs progress across devices.\n\n"
            "Sign up at trakt.tv\n"
            "Then connect it in step 3."
        )
    elif choice == 2:
        dialog.ok(
            "Umbrella",
            "Streaming addon for movies and TV shows.\n\n"
            "[COLOR yellow]Requires Real Debrid to function.[/COLOR]\n"
            "Free torrent sources are disabled.\n\n"
            "CocoScrapers installs automatically on first use."
        )
    elif choice == 3:
        dialog.ok(
            "The Crew",
            "Addon for live sports streaming.\n\n"
            "Free, no Real Debrid needed.\n\n"
            "[COLOR yellow]VPN RECOMMENDED[/COLOR]\n"
            "Use a VPN when streaming sports."
        )
    elif choice == 4:
        dialog.ok(
            "VPN Usage",
            "[COLOR cyan]Umbrella (Movies/TV):[/COLOR]\n"
            "VPN not needed - Real Debrid protects you.\n\n"
            "[COLOR cyan]The Crew (Sports):[/COLOR]\n"
            "[COLOR yellow]VPN RECOMMENDED[/COLOR]\n"
            "Sports streams are direct connections.\n"
            "Use a VPN for privacy protection.\n\n"
            "Enable VPN on your device/router before\n"
            "using The Crew."
        )
    elif choice == 5:
        dialog.ok(
            "Troubleshooting",
            "Slow/freezing: Maintenance > Quick Clean\n"
            "No streams: Set up Real Debrid\n"
            "Addon missing: Re-run Install Addons\n"
            "Still broken: Restart Kodi"
        )