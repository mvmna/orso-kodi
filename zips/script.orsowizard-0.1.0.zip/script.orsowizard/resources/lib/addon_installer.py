import xbmc
import xbmcgui
import xbmcaddon

from .telemetry import log

ADDONS_TO_INSTALL = [
    {
        "id": "plugin.video.umbrella",
        "name": "Umbrella",
        "description": "Movies & TV (requires Real Debrid)",
        "repo_name": "Umbrella Repository",
    },
    {
        "id": "script.module.cocoscrapers",
        "name": "CocoScrapers Module",
        "description": "External scraper provider for Umbrella",
        "repo_name": "CocoScrapers Repository",
    },
    {
        "id": "plugin.video.thecrew",
        "name": "The Crew",
        "description": "Live Sports (free, VPN recommended)",
        "repo_name": "The Crew Repository",
    },
]


def run_addon_installer():
    """Guide users to install streaming addons. Returns True if navigating away."""
    dialog = xbmcgui.Dialog()
    
    # Check what's already installed
    installed = [a for a in ADDONS_TO_INSTALL if is_addon_installed(a["id"])]
    not_installed = [a for a in ADDONS_TO_INSTALL if not is_addon_installed(a["id"])]
    
    if not not_installed:
        dialog.ok(
            "All Addons Installed",
            "All streaming addons are already installed!\n\n" +
            "\n".join([f"- {a['name']}" for a in installed])
        )
        return False
    
    # Build instructions
    instructions = "Install these addons from their repositories:\n\n"
    for addon in not_installed:
        desc = addon.get('description', '')
        instructions += f"[COLOR cyan]{addon['name']}[/COLOR] - {desc}\n"
        instructions += f"  {addon['repo_name']} > Video add-ons > {addon['name']}\n\n"
    
    dialog.ok(
        "Install Addons",
        instructions + 
        "Click OK to open the addon browser.\n"
        "Come back to the wizard when done."
    )
    
    # Update repos and navigate to addon browser
    xbmc.executebuiltin("UpdateAddonRepos")
    xbmc.sleep(300)
    xbmc.executebuiltin("ActivateWindow(10040,addons://repos/)")
    return True  # Signal that we navigated away


def is_addon_installed(addon_id):
    """Check if an addon is installed."""
    try:
        xbmcaddon.Addon(addon_id)
        return True
    except:
        return False
