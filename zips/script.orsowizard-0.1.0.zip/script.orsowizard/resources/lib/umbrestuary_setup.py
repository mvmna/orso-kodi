import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import sqlite3
import os

from .telemetry import log
from .kodi import jsonrpc

UMBRESTUARY_ADDON_ID = "skin.umbrestuary"
HELPER_ADDON_ID = "script.umbrestuary.helper"

# Widget configurations for Orso setup
# main_menu_path: what opens when clicking the menu item
# widgets: content rows shown on home screen when menu is selected
# widget_type: "WidgetListPoster", "WidgetListBigPoster", etc.
WIDGET_CONFIG = [
    {
        "menu": "movie",
        "label": "Movies",
        "main_menu_path": "plugin://plugin.video.umbrella/?action=movieNavigator&folderName=Discover+Movies",
        "widgets": [
            {
                "label": "Continue Watching",
                "path": "plugin://plugin.video.umbrella/?action=moviesUnfinished&url=traktunfinished&folderName=Finish+Watching",
                "widget_type": "WidgetListBigPoster",
            },
            {
                "label": "Recently Released",
                "path": "plugin://plugin.video.umbrella/?action=movies&url=trakttrending_recent&folderName=Trending+Recently+Released+%28Trakt%29",
                "widget_type": "WidgetListPoster",
            },
            {
                "label": "Action",
                "path": "plugin://plugin.video.umbrella/?action=trakt_genre&listtype=trending&mediatype=Movies&genre=Action&url=action&folderName=Trending+Action+Movies",
                "widget_type": "WidgetListPoster",
            },
            {
                "label": "Comedy",
                "path": "plugin://plugin.video.umbrella/?action=trakt_genre&listtype=trending&mediatype=Movies&genre=Comedy&url=comedy&folderName=Trending+Comedy+Movies",
                "widget_type": "WidgetListPoster",
            },
            {
                "label": "Documentary",
                "path": "plugin://plugin.video.umbrella/?action=trakt_genre&listtype=trending&mediatype=Movies&genre=Documentary&url=documentary&folderName=Trending+Documentary+Movies",
                "widget_type": "WidgetListPoster",
            },
            {
                "label": "Drama",
                "path": "plugin://plugin.video.umbrella/?action=trakt_genre&listtype=trending&mediatype=Movies&genre=Drama&url=drama&folderName=Trending+Drama+Movies",
                "widget_type": "WidgetListPoster",
            },
            {
                "label": "Fantasy",
                "path": "plugin://plugin.video.umbrella/?action=trakt_genre&listtype=trending&mediatype=Movies&genre=Fantasy&url=fantasy&folderName=Trending+Fantasy+Movies",
                "widget_type": "WidgetListPoster",
            },
            {
                "label": "Horror",
                "path": "plugin://plugin.video.umbrella/?action=trakt_genre&listtype=trending&mediatype=Movies&genre=Horror&url=horror&folderName=Trending+Horror+Movies",
                "widget_type": "WidgetListPoster",
            },
            {
                "label": "Science Fiction",
                "path": "plugin://plugin.video.umbrella/?action=trakt_genre&listtype=trending&mediatype=Movies&genre=Science+Fiction&url=science-fiction&folderName=Trending+Science+Fiction+Movies",
                "widget_type": "WidgetListPoster",
            },
            {
                "label": "Thriller",
                "path": "plugin://plugin.video.umbrella/?action=trakt_genre&listtype=trending&mediatype=Movies&genre=Thriller&url=thriller&folderName=Trending+Thriller+Movies",
                "widget_type": "WidgetListPoster",
            },
        ],
    },
    {
        "menu": "tvshow", 
        "label": "TV Shows",
        "main_menu_path": "plugin://plugin.video.umbrella/?action=tvNavigator&folderName=Discover+TV+Shows",
        "widgets": [
            {
                "label": "Continue Watching",
                "path": "plugin://plugin.video.umbrella/?action=episodesUnfinished&url=traktunfinished&folderName=Finish+Watching",
                "widget_type": "WidgetListBigPoster",
            },
            {
                "label": "Recently Released",
                "path": "plugin://plugin.video.umbrella/?action=tvshows&url=trakttrending_recent&folderName=Trending+Recently+Released+%28Trakt%29",
                "widget_type": "WidgetListPoster",
            },
            {
                "label": "Action",
                "path": "plugin://plugin.video.umbrella/?action=trakt_genre&listtype=trending&mediatype=TVShows&genre=Action&url=action&folderName=Trending+Action+TV+Shows",
                "widget_type": "WidgetListPoster",
            },
            {
                "label": "Comedy",
                "path": "plugin://plugin.video.umbrella/?action=trakt_genre&listtype=trending&mediatype=TVShows&genre=Comedy&url=comedy&folderName=Trending+Comedy+TV+Shows",
                "widget_type": "WidgetListPoster",
            },
            {
                "label": "Drama",
                "path": "plugin://plugin.video.umbrella/?action=trakt_genre&listtype=trending&mediatype=TVShows&genre=Drama&url=drama&folderName=Trending+Drama+TV+Shows",
                "widget_type": "WidgetListPoster",
            },
            {
                "label": "Fantasy",
                "path": "plugin://plugin.video.umbrella/?action=trakt_genre&listtype=trending&mediatype=TVShows&genre=Fantasy&url=fantasy&folderName=Trending+Fantasy+TV+Shows",
                "widget_type": "WidgetListPoster",
            },
            {
                "label": "Horror",
                "path": "plugin://plugin.video.umbrella/?action=trakt_genre&listtype=trending&mediatype=TVShows&genre=Horror&url=horror&folderName=Trending+Horror+TV+Shows",
                "widget_type": "WidgetListPoster",
            },
            {
                "label": "Reality",
                "path": "plugin://plugin.video.umbrella/?action=trakt_genre&listtype=trending&mediatype=TVShows&genre=Reality&url=reality&folderName=Trending+Reality+TV+Shows",
                "widget_type": "WidgetListPoster",
            },
            {
                "label": "Science Fiction",
                "path": "plugin://plugin.video.umbrella/?action=trakt_genre&listtype=trending&mediatype=TVShows&genre=Science+Fiction&url=science-fiction&folderName=Trending+Science+Fiction+TV+Shows",
                "widget_type": "WidgetListPoster",
            },
            {
                "label": "Thriller",
                "path": "plugin://plugin.video.umbrella/?action=trakt_genre&listtype=trending&mediatype=TVShows&genre=Thriller&url=thriller&folderName=Trending+Thriller+TV+Shows",
                "widget_type": "WidgetListPoster",
            },
        ],
    },
    {
        "menu": "custom1",
        "label": "Sports",
        "main_menu_path": "plugin://plugin.video.thecrew/?action=sports",
        "widgets": [
            {
                "label": "NFL",
                "path": "plugin://plugin.video.thecrew/?action=nfl",
                "widget_type": "WidgetListCategory",
            },
            {
                "label": "NHL",
                "path": "plugin://plugin.video.thecrew/?action=nhl",
                "widget_type": "WidgetListCategory",
            },
            {
                "label": "NBA",
                "path": "plugin://plugin.video.thecrew/?action=nba",
                "widget_type": "WidgetListCategory",
            },
            {
                "label": "MLB",
                "path": "plugin://plugin.video.thecrew/?action=mlb",
                "widget_type": "WidgetListCategory",
            },
            {
                "label": "NCAAF",
                "path": "plugin://plugin.video.thecrew/?action=ncaaf",
                "widget_type": "WidgetListCategory",
            },
            {
                "label": "NCAAB",
                "path": "plugin://plugin.video.thecrew/?action=ncaab",
                "widget_type": "WidgetListCategory",
            },
            {
                "label": "UFC / MMA",
                "path": "plugin://plugin.video.thecrew/?action=ufc",
                "widget_type": "WidgetListCategory",
            },
            {
                "label": "Boxing",
                "path": "plugin://plugin.video.thecrew/?action=boxing",
                "widget_type": "WidgetListCategory",
            },
            {
                "label": "Soccer",
                "path": "plugin://plugin.video.thecrew/?action=soccer",
                "widget_type": "WidgetListCategory",
            },
            {
                "label": "Golf",
                "path": "plugin://plugin.video.thecrew/?action=golf",
                "widget_type": "WidgetListCategory",
            },
        ],
    },
]

# Menu items to hide
MENUS_TO_HIDE = [
    "HomeMenuNoMusicButton",
    "HomeMenuNoMusicVideoButton",
    "HomeMenuNoTVButton",
    "HomeMenuNoRadioButton", 
    "HomeMenuNoPicturesButton",
    "HomeMenuNoVideosButton",
    "HomeMenuNoGamesButton",
    "HomeMenuNoFavButton",
    "HomeMenuNoWeatherButton",
    "HomeMenuNoCustom2Button",
    "HomeMenuNoCustom3Button",
]

# Menu items to show
MENUS_TO_SHOW = [
    "HomeMenuNoMoviesButton",
    "HomeMenuNoTVShowsButton",
    "HomeMenuNoCustom1Button",
    "HomeMenuNoProgramsButton",
]


def is_umbrestuary_installed():
    """Check if Umbrestuary skin is installed."""
    try:
        xbmcaddon.Addon(UMBRESTUARY_ADDON_ID)
        return True
    except:
        return False


def setup_widget_database():
    """Set up the Umbrestuary helper database with our widget configs."""
    db_path = xbmcvfs.translatePath(
        "special://profile/addon_data/script.umbrestuary.helper/cpath_cache.db"
    )
    settings_path = xbmcvfs.translatePath(
        "special://profile/addon_data/script.umbrestuary.helper/"
    )
    
    # Create directory if needed
    if not xbmcvfs.exists(settings_path):
        xbmcvfs.mkdirs(settings_path)
    
    try:
        conn = sqlite3.connect(db_path, timeout=20)
        conn.execute(
            "CREATE TABLE IF NOT EXISTS custom_paths "
            "(cpath_setting text unique, cpath_path text, cpath_header text, cpath_type text, cpath_label text)"
        )
        
        for config in WIDGET_CONFIG:
            menu = config["menu"]
            
            # Set up main menu path (what happens when you click the menu item)
            # Only if main_menu_path is specified - otherwise use Kodi default
            if config.get("main_menu_path"):
                main_menu_setting = f"{menu}.main_menu"
                conn.execute(
                    "INSERT OR REPLACE INTO custom_paths VALUES (?, ?, ?, ?, ?)",
                    (main_menu_setting, config["main_menu_path"], config["label"], "main_menu", config["label"])
                )
                log(f"Added main menu: {menu} -> {config['label']}")
            
            # Set up widgets (content previews shown on home screen)
            for i, widget in enumerate(config.get("widgets", []), start=1):
                widget_setting = f"{menu}.widget.{i}"
                conn.execute(
                    "INSERT OR REPLACE INTO custom_paths VALUES (?, ?, ?, ?, ?)",
                    (widget_setting, widget["path"], widget["label"], widget["widget_type"], widget["label"])
                )
                log(f"Added widget: {menu}.widget.{i} -> {widget['label']}")
        
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        log(f"Failed to setup widget database: {e}")
        return False


def configure_skin_settings():
    """Configure skin boolean settings to hide/show menu items."""
    # Hide unwanted menus
    for setting in MENUS_TO_HIDE:
        xbmc.executebuiltin(f"Skin.SetBool({setting})")
        log(f"Hidden: {setting}")
    
    # Show wanted menus (reset the bool)
    for setting in MENUS_TO_SHOW:
        xbmc.executebuiltin(f"Skin.Reset({setting})")
        log(f"Showing: {setting}")
    
    # Set menu labels
    xbmc.executebuiltin('Skin.SetString(MenuMovieLabel, Movies)')
    xbmc.executebuiltin('Skin.SetString(MenuTVShowLabel, TV Shows)')
    xbmc.executebuiltin('Skin.SetString(MenuCustom1Label, Sports)')


def run_umbrestuary_setup():
    """Configure Umbrestuary programmatically. Returns True if user should come back later."""
    dialog = xbmcgui.Dialog()

    # First check if Umbrestuary is installed
    if not is_umbrestuary_installed():
        dialog.ok(
            "Umbrestuary Not Installed",
            "The Umbrestuary skin is required for home screen setup.\n\n"
            "Click OK to open the skin installer.\n"
            "Search for 'Umbrestuary' and install it.\n\n"
            "Then come back to step 4."
        )
        xbmc.executebuiltin("ActivateWindow(10040,addons://all/xbmc.gui.skin/)")
        return True
    
    # Check if Umbrestuary is the active skin
    resp = jsonrpc("Settings.GetSettingValue", {"setting": "lookandfeel.skin"})
    skin = resp.get("result", {}).get("value", "")
    log(f"Active skin: {skin}")

    if "umbrestuary" not in skin.lower():
        if dialog.yesno(
            "Activate Umbrestuary",
            f"Umbrestuary is installed but not active.\n"
            f"Current skin: {skin}\n\n"
            "Would you like to activate Umbrestuary now?\n"
            "(Kodi will reload)"
        ):
            jsonrpc("Settings.SetSettingValue", {
                "setting": "lookandfeel.skin",
                "value": UMBRESTUARY_ADDON_ID
            })
            xbmc.sleep(500)
            dialog.ok(
                "Skin Changed",
                "Umbrestuary is now active.\n\n"
                "Please re-open the wizard and run step 4 again\n"
                "to configure your home screen."
            )
            return True
        else:
            return False

    # Umbrestuary is installed and active
    if not dialog.yesno(
        "Set Up Home Screen",
        "Configure home screen with:\n\n"
        "- Movies: 10 widgets from Umbrella\n"
        "- TV Shows: 10 widgets from Umbrella\n"
        "- Sports: 10 widgets from The Crew\n\n"
        "Hide unused items (Music, Games, etc.)?"
    ):
        return False

    # Show progress
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("Setting Up Home Screen", "Please wait...")
    
    # Step 1: Configure skin boolean settings
    pDialog.update(25, "Configuring menu visibility...")
    configure_skin_settings()
    xbmc.sleep(500)
    
    # Step 2: Set up widget database
    pDialog.update(50, "Setting up widgets...")
    db_success = setup_widget_database()
    xbmc.sleep(500)
    
    # Step 3: Call helper to regenerate XML files
    pDialog.update(75, "Regenerating skin files...")
    xbmc.executebuiltin("RunScript(script.umbrestuary.helper,mode=remake_all_cpaths)")
    xbmc.sleep(2000)  # Give it time to regenerate
    
    pDialog.update(100, "Done!")
    xbmc.sleep(500)
    pDialog.close()
    
    if db_success:
        dialog.ok(
            "Home Screen Configured",
            "Set up 3 menu items:\n"
            "- Movies: 10 widgets from Umbrella\n"
            "- TV Shows: 10 widgets from Umbrella\n" 
            "- Sports: 10 widgets from The Crew\n\n"
            "Reload skin to apply changes."
        )
        
        if dialog.yesno("Reload Skin", "Reload skin now to see changes?"):
            xbmc.executebuiltin("ReloadSkin()")
    else:
        dialog.ok(
            "Partial Setup",
            "Menu visibility configured, but widgets\n"
            "may need manual setup in Skin Settings.\n\n"
            "Go to: Skin Settings > Configure Shortcuts"
        )
    
    return False


def get_current_skin():
    """Return the currently active skin ID."""
    resp = jsonrpc("Settings.GetSettingValue", {"setting": "lookandfeel.skin"})
    return resp.get("result", {}).get("value", "")