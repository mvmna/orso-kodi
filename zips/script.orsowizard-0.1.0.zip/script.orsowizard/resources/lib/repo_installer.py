import os
import xbmc
import xbmcgui
import xbmcvfs

from .net import download_to_file
from .telemetry import log
from .kodi import install_zip, ensure_unknown_sources


def run_repo_installer():
    """Install streaming repositories."""
    import xbmcaddon
    dialog = xbmcgui.Dialog()
    
    # Check unknown sources first
    if not ensure_unknown_sources():
        return
    
    addon = xbmcaddon.Addon()
    
    urls = [
        ("Umbrella", addon.getSetting("repo_zip_url_1").strip()),
        ("The Crew", addon.getSetting("repo_zip_url_2").strip()),
        ("CocoScrapers", addon.getSetting("repo_zip_url_3").strip()),
    ]
    urls = [(name, url) for name, url in urls if url]

    if not urls:
        dialog.ok("Error", "No repository URLs configured.")
        return

    repo_names = ", ".join([name for name, url in urls])
    if not dialog.yesno("Install Repositories", f"Install {repo_names}?"):
        return

    packages_dir = xbmcvfs.translatePath("special://home/addons/packages/")
    if not xbmcvfs.exists(packages_dir):
        xbmcvfs.mkdirs(packages_dir)

    installed = 0
    failed = []
    
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("Installing Repositories", "Please wait...")
    
    for i, (name, url) in enumerate(urls):
        if pDialog.iscanceled():
            break
            
        progress = int((i / len(urls)) * 100)
        pDialog.update(progress, f"Downloading {name}...")
        
        try:
            filename = os.path.basename(url.split("?")[0]) or "repo.zip"
            dest = os.path.join(packages_dir, filename)
            log(f"Downloading: {url}")
            download_to_file(url, dest)
            
            pDialog.update(progress, f"Installing {name}...")
            install_zip(dest)
            xbmc.sleep(1500)
            installed += 1
            log(f"Successfully installed: {name}")
        except Exception as e:
            log(f"Failed to install {name}: {e}")
            failed.append(f"{name} ({str(e)[:30]})")
    
    pDialog.close()
    
    # Final update to make sure Kodi sees the repos
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")

    if failed:
        dialog.ok("Done", f"Installed {installed}, failed:\n" + "\n".join(failed))
    else:
        dialog.ok("Done", f"Installed {installed} repositories.\n\nProceed to step 2 to install addons.")