import os
import shutil
import xbmc
import xbmcgui
import xbmcvfs

from .telemetry import log

def run_maintenance_menu(handle, base_url):
    import xbmcplugin
    xbmcplugin.setPluginCategory(handle, "Maintenance")

    def add(title, action, description=""):
        import urllib.parse
        url = f"{base_url}?{urllib.parse.urlencode({'action': 'maintenance_run', 'task': action})}"
        li = xbmcgui.ListItem(label=title)
        if description:
            li.setInfo("video", {"plot": description})
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)

    add("[COLOR gold]Quick Clean[/COLOR]", "quick_clean", "Clear packages + thumbnails")
    add("Clear Packages", "clear_packages", "Remove downloaded addon installers")
    add("Clear Thumbnails", "clear_thumbnails", "Remove cached images")
    add("Check for Updates", "update_check", "Check for addon updates")

    xbmcplugin.endOfDirectory(handle)

def _userdata_path():
    return xbmcvfs.translatePath("special://home/userdata/")

def _profile_path():
    return xbmcvfs.translatePath("special://profile/")

def quick_clean():
    """Run a safe cleanup of packages and thumbnails."""
    dialog = xbmcgui.Dialog()
    
    if not dialog.yesno("Quick Clean", "Clear packages and thumbnails?"):
        return
    
    path1 = xbmcvfs.translatePath("special://home/addons/packages/")
    path2 = xbmcvfs.translatePath("special://profile/Thumbnails/")
    _rm_tree(path1)
    _rm_tree(path2)
    
    dialog.notification("Orso Wizard", "Cleaned!", time=2000)

def clear_packages():
    """Clear downloaded addon installer packages."""
    path = xbmcvfs.translatePath("special://home/addons/packages/")
    _rm_tree(path)
    xbmcgui.Dialog().notification(
        "Orso Wizard", 
        "Addon packages cleared", 
        time=2000
    )

def clear_thumbnails():
    """Clear cached thumbnail images."""
    path = xbmcvfs.translatePath("special://profile/Thumbnails/")
    _rm_tree(path)
    xbmcgui.Dialog().notification(
        "Orso Wizard", 
        "Thumbnails cleared - images will reload", 
        time=2000
    )

def clear_addon_data_cache():
    """Clear addon data cache (selective - only safe targets)."""
    addon_data = xbmcvfs.translatePath("special://profile/addon_data/")
    safe_targets = []
    for p in safe_targets:
        _rm_tree(p)
    xbmcgui.Dialog().notification(
        "Orso Wizard", 
        "Addon cache cleared", 
        time=2000
    )

def update_check():
    """Tell Kodi to check for addon updates now."""
    xbmc.executebuiltin("UpdateAddonRepos")
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmcgui.Dialog().notification("Orso Wizard", "Checking for updates...", time=2000)

def _rm_tree(path):
    try:
        if not path or not xbmcvfs.exists(path):
            return
        # xbmcvfs doesn't have full shutil parity, so use os/shutil where possible.
        if os.path.isdir(path):
            shutil.rmtree(path, ignore_errors=True)
        else:
            try:
                os.remove(path)
            except Exception:
                pass
        log(f"Removed: {path}")
    except Exception as e:
        xbmcgui.Dialog().ok("Orso Wizard", f"Failed to remove:\n{path}\n\n{e}")