import json
import xbmc
import xbmcaddon
import xbmcgui

from .telemetry import log

def jsonrpc(method, params=None):
    payload = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        payload["params"] = params
    raw = xbmc.executeJSONRPC(json.dumps(payload))
    try:
        return json.loads(raw)
    except Exception:
        return {"raw": raw}

def is_unknown_sources_enabled():
    """Check if installation from unknown sources is enabled."""
    resp = jsonrpc("Settings.GetSettingValue", {"setting": "addons.unknownsources"})
    return resp.get("result", {}).get("value", False)

def enable_unknown_sources():
    """Try to enable unknown sources programmatically."""
    resp = jsonrpc("Settings.SetSettingValue", {
        "setting": "addons.unknownsources",
        "value": True
    })
    return resp.get("result") == True

def ensure_unknown_sources():
    """Make sure unknown sources is enabled, prompting user if needed."""
    if is_unknown_sources_enabled():
        return True
    
    dialog = xbmcgui.Dialog()
    dialog.ok(
        "Enable Unknown Sources",
        "Kodi blocks addon installs by default.\n\n"
        "Please enable 'Unknown sources':\n"
        "Settings > System > Add-ons > Unknown sources\n\n"
        "Then run this step again."
    )
    
    # Try to open the settings page
    xbmc.executebuiltin("ActivateWindow(systemsettings)")
    return False

def enable_addon(addon_id: str):
    resp = jsonrpc("Addons.SetAddonEnabled", {"addonid": addon_id, "enabled": True})
    log(f"Enable addon {addon_id}: {resp}")
    return resp

def set_addon_setting(addon_id: str, setting_id: str, value: str):
    """Programmatically set another add-on's setting."""
    try:
        a = xbmcaddon.Addon(addon_id)
        a.setSetting(setting_id, value)
        log(f"Set {addon_id}.{setting_id} = {value}")
        return True
    except Exception as e:
        log(f"Failed setSetting {addon_id}.{setting_id}: {e}")
        return False

def install_zip(zip_path: str):
    """Extract addon zip to addons folder and enable it."""
    import zipfile
    import os
    import xml.etree.ElementTree as ET
    import xbmcvfs
    import shutil
    
    addons_dir = xbmcvfs.translatePath("special://home/addons/")
    
    try:
        with zipfile.ZipFile(zip_path, 'r') as zf:
            names = zf.namelist()
            if not names:
                raise Exception("Empty zip file")
            
            # Get folder name from zip
            folder_name = names[0].split('/')[0]
            log(f"Extracting {folder_name} from {zip_path}")
            
            # Extract to addons directory
            zf.extractall(addons_dir)
            log(f"Extracted to {addons_dir}")
            
            # Read the actual addon ID from addon.xml
            addon_xml_path = os.path.join(addons_dir, folder_name, "addon.xml")
            if os.path.exists(addon_xml_path):
                tree = ET.parse(addon_xml_path)
                actual_addon_id = tree.getroot().get("id")
                
                # If folder name doesn't match addon ID, rename it
                if actual_addon_id and actual_addon_id != folder_name:
                    log(f"Addon ID mismatch: folder={folder_name}, id={actual_addon_id}")
                    old_path = os.path.join(addons_dir, folder_name)
                    new_path = os.path.join(addons_dir, actual_addon_id)
                    
                    # Remove existing if present
                    if os.path.exists(new_path):
                        shutil.rmtree(new_path)
                    
                    os.rename(old_path, new_path)
                    log(f"Renamed {folder_name} -> {actual_addon_id}")
                    folder_name = actual_addon_id
        
        # Tell Kodi to scan for new addons
        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.sleep(1000)
        
        # Try to enable the addon
        enable_addon(folder_name)
        
        return True
    except Exception as e:
        log(f"Failed to install zip {zip_path}: {e}")
        raise