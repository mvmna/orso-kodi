import xbmc
import xbmcgui
import xbmcaddon

from .telemetry import log
from .kodi import set_addon_setting

UMBRELLA_ADDON_ID = "plugin.video.umbrella"
COCOSCRAPERS_MODULE_ID = "script.module.cocoscrapers"


def run_api_keys():
    """Configure Real Debrid / Trakt for Umbrella."""
    dialog = xbmcgui.Dialog()

    try:
        addon = xbmcaddon.Addon(UMBRELLA_ADDON_ID)
    except Exception as e:
        log(f"Umbrella not installed: {e}")
        dialog.ok("Umbrella Not Found", "Install Umbrella first (step 2).")
        return

    # Apply ALL settings BEFORE opening Umbrella settings dialog
    # This ensures settings are written to disk before Umbrella reads them
    configure_umbrella_debrid_only()
    configure_cocoscrapers()
    configure_umbrella_autoselect()
    
    # Clear Umbrella's cached settings so it re-reads from disk
    home_window = xbmcgui.Window(10000)
    home_window.clearProperty('umbrella_settings')
    log("Cleared Umbrella settings cache")
    
    if not dialog.yesno(
        "Configure Umbrella",
        "Umbrella has been configured with:\n\n"
        "- Autoplay enabled (no source selection)\n"
        "- CocoScrapers as external provider\n"
        "- Real Debrid-only mode\n\n"
        "[COLOR yellow]Open settings to authorize Real Debrid?[/COLOR]\n"
        "Go to 'Accounts' > 'Real-Debrid' section."
    ):
        return
        
    addon.openSettings()
    
    dialog.notification("Orso Wizard", "Umbrella configured", time=2000)


def configure_cocoscrapers():
    """Configure Umbrella to use CocoScrapers as external provider.
    
    Must follow Umbrella's exact setting order pattern from tools.py:
    1. Set homeWindow property 'umbrella.updateSettings' to 'false'
    2. Set 'external_provider.name' setting
    3. Set homeWindow property 'umbrella.updateSettings' to 'true'  
    4. Set 'external_provider.module' setting
    """
    # Check if CocoScrapers is installed
    try:
        xbmcaddon.Addon(COCOSCRAPERS_MODULE_ID)
    except:
        log("CocoScrapers not installed, skipping external provider config")
        return False
    
    # Check if Umbrella is installed
    try:
        umbrella = xbmcaddon.Addon(UMBRELLA_ADDON_ID)
    except:
        log("Umbrella not installed, skipping external provider config")
        return False
    
    # Get Kodi's home window for setting the update property
    home_window = xbmcgui.Window(10000)
    
    # Follow Umbrella's exact pattern from tools.py external_providers()
    # Step 1: Pause settings sync
    home_window.setProperty('umbrella.updateSettings', 'false')
    
    # Step 2: Set the provider name (module name to import)
    umbrella.setSetting('external_provider.name', 'cocoscrapers')
    log("Set external_provider.name = cocoscrapers")
    
    # Step 3: Resume settings sync
    home_window.setProperty('umbrella.updateSettings', 'true')
    
    # Step 4: Set the provider module (addon ID)
    umbrella.setSetting('external_provider.module', COCOSCRAPERS_MODULE_ID)
    log(f"Set external_provider.module = {COCOSCRAPERS_MODULE_ID}")
    
    # Step 5: Enable external providers
    umbrella.setSetting('provider.external.enabled', 'true')
    log("Set provider.external.enabled = true")
    
    log("CocoScrapers configured as external provider for Umbrella")
    return True


def configure_umbrella_debrid_only():
    """Configure Umbrella to only use Real Debrid sources (no free torrents)."""
    settings = [
        # Provider settings - disable non-debrid sources
        ("provider.sources.uncached", "false"),      # Hide uncached (non-debrid) torrents
        ("scraper.timeout", "60"),                   # Reasonable timeout
        
        # Results filtering
        ("results.hideuncached", "true"),            # Hide uncached results in list
        ("results.cachedonly", "true"),              # Only show cached (Real Debrid) results
        
        # Playback - prefer debrid
        ("playback.preferresolve", "1"),             # Prefer debrid resolving
    ]

    success = True
    for setting_id, value in settings:
        result = set_addon_setting(UMBRELLA_ADDON_ID, setting_id, value)
        if result:
            log(f"Set Umbrella {setting_id}={value}")
        else:
            log(f"Could not set {setting_id} (may not exist in this version)")

    log("Umbrella configured for Real Debrid-only mode")
    return success


def configure_umbrella_autoselect():
    """Set Umbrella to auto-select best source (no manual source selection).
    
    play.mode.movie and play.mode.tv:
    - '0' = Directory (shows source list for manual selection)
    - '1' = Autoplay (automatically plays best source)
    
    Umbrella caches settings in window properties, so we also update those.
    """
    try:
        umbrella = xbmcaddon.Addon(UMBRELLA_ADDON_ID)
    except:
        log("Umbrella not installed, skipping autoselect config")
        return False
    
    home_window = xbmcgui.Window(10000)
    
    # Pause settings sync while making multiple changes
    home_window.setProperty('umbrella.updateSettings', 'false')
    
    # Set autoplay mode for both movies and TV shows
    umbrella.setSetting('play.mode.movie', '1')  # Autoplay movies
    umbrella.setSetting('play.mode.tv', '1')     # Autoplay TV shows
    log("Set play.mode.movie = 1 (Autoplay)")
    log("Set play.mode.tv = 1 (Autoplay)")
    
    # Additional autoplay quality settings
    settings = [
        ("autoplay.sd", "true"),   # Include SD quality in autoplay
        ("autoplay.hd", "true"),   # Include HD quality in autoplay  
        ("autoplay.uhd", "true"),  # Include 4K quality in autoplay
    ]
    
    for setting_id, value in settings:
        umbrella.setSetting(setting_id, value)
        log(f"Set Umbrella {setting_id}={value}")

    # Resume settings sync
    home_window.setProperty('umbrella.updateSettings', 'true')
    
    # Also update Umbrella's cached window properties directly
    # These are what Umbrella actually checks during playback
    home_window.setProperty('umbrella.autoPlaytv.enabled', 'true')
    home_window.setProperty('umbrella.autoPlayMovie.enabled', 'true')
    log("Updated Umbrella window properties for autoplay")
    
    # Clear the settings cache so Umbrella re-reads from disk
    home_window.clearProperty('umbrella_settings')
    log("Cleared Umbrella settings cache")

    log("Umbrella auto-select configured - will automatically play best source")
    return True
