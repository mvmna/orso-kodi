import os
import xml.etree.ElementTree as ET
import xbmcvfs
import xbmcgui

from .telemetry import log


def run_kodi_config():
    """Apply optimized Kodi settings."""
    import xbmc
    dialog = xbmcgui.Dialog()
    
    if not dialog.yesno(
        "Optimize Kodi",
        "Apply performance settings?\n\n"
        "- Larger buffer (less buffering)\n"
        "- Better network timeouts\n\n"
        "Recommended for Fire TV / Android."
    ):
        return
    
    if create_advancedsettings():
        if dialog.yesno("Done", "Settings saved. Restart Kodi now?"):
            xbmc.executebuiltin("Quit")
    else:
        dialog.ok("Error", "Could not save settings.")


def create_advancedsettings():
    """Create or merge advancedsettings.xml for optimized streaming.
    
    Merges with existing settings rather than overwriting them.
    """
    userdata = xbmcvfs.translatePath("special://userdata/")
    xml_path = os.path.join(userdata, "advancedsettings.xml")

    # Try to load existing file, or create new root
    if xbmcvfs.exists(xml_path):
        try:
            tree = ET.parse(xml_path)
            root = tree.getroot()
            log(f"Merging with existing advancedsettings.xml")
        except ET.ParseError as e:
            log(f"Failed to parse existing advancedsettings.xml: {e}")
            choice = xbmcgui.Dialog().yesno(
                "Orso Wizard",
                "Existing advancedsettings.xml is invalid.\n\n"
                "Create a new one?\n"
                "(Existing file will be replaced)"
            )
            if not choice:
                return False
            root = ET.Element("advancedsettings")
    else:
        root = ET.Element("advancedsettings")

    # Helper to get or create a section
    def get_or_create(parent, tag):
        elem = parent.find(tag)
        if elem is None:
            elem = ET.SubElement(parent, tag)
        return elem

    # Helper to set a child element's text
    def set_child(parent, tag, value):
        child = parent.find(tag)
        if child is None:
            child = ET.SubElement(parent, tag)
        child.text = value

    # Cache settings for optimal streaming on Fire TV / low-memory devices
    cache = get_or_create(root, "cache")
    set_child(cache, "memorysize", "157286400")  # 150MB
    set_child(cache, "buffermode", "1")  # Buffer all internet filesystems
    set_child(cache, "readfactor", "4")  # Read ahead factor

    # Network settings
    network = get_or_create(root, "network")
    set_child(network, "curlclienttimeout", "30")
    set_child(network, "curllowspeedtime", "30")

    # Video settings
    video = get_or_create(root, "video")
    set_child(video, "playcountminimumpercent", "90")

    # GUI settings for cleanup
    gui = get_or_create(root, "gui")
    set_child(gui, "algorithmdirtyregions", "3")

    # Write file with proper formatting
    tree = ET.ElementTree(root)
    try:
        ET.indent(tree, space="  ")
    except AttributeError:
        pass  # ET.indent not available in older Python versions
    
    try:
        tree.write(xml_path, encoding="utf-8", xml_declaration=True)
        log(f"Saved advancedsettings.xml at {xml_path}")
        return True
    except Exception as e:
        log(f"Failed to write advancedsettings.xml: {e}")
        xbmcgui.Dialog().ok("Orso Wizard", f"Failed to save settings:\n\n{e}")
        return False


def get_advancedsettings_path():
    """Return the path to advancedsettings.xml."""
    userdata = xbmcvfs.translatePath("special://userdata/")
    return os.path.join(userdata, "advancedsettings.xml")
