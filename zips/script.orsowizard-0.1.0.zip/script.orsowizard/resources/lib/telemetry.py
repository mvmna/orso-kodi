import xbmc
import xbmcaddon

def log(msg: str):
    try:
        addon = xbmcaddon.Addon()
        debug = addon.getSettingBool("debug")
    except Exception:
        debug = False
    if debug:
        xbmc.log(f"[OrsoWizard] {msg}", level=xbmc.LOGINFO)