import urllib.request
import urllib.error

from .telemetry import log


def download_to_file(url: str, dest_path: str):
    """Download a file from URL to local path with error handling."""
    try:
        req = urllib.request.Request(
            url,
            headers={"User-Agent": "Kodi/21.0 (compatible; OrsoWizard)"}
        )
        with urllib.request.urlopen(req, timeout=60) as resp:
            data = resp.read()
        
        with open(dest_path, "wb") as f:
            f.write(data)
        
        log(f"Downloaded: {url} -> {dest_path}")
        return True
        
    except urllib.error.HTTPError as e:
        log(f"HTTP error downloading {url}: {e.code} {e.reason}")
        raise
    except urllib.error.URLError as e:
        log(f"URL error downloading {url}: {e.reason}")
        raise
    except IOError as e:
        log(f"File write error for {dest_path}: {e}")
        raise
    except Exception as e:
        log(f"Unexpected error downloading {url}: {e}")
        raise