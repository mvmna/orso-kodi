# Kodi Script Add-on entrypoint.
# This script provides a dialog-based menu UI.

from resources.lib.ui import run_wizard

if __name__ == "__main__":
    run_wizard()